var searchData=
[
  ['main',['main',['../classMathematicalOperations.html#a43c78e2b0cb35347adec1161b35cd178',1,'MathematicalOperations']]],
  ['mathematicaloperations',['MathematicalOperations',['../classMathematicalOperations.html',1,'']]],
  ['minus',['minus',['../classMathematicalOperations.html#a492270b183076978e30973fea2a81fa4',1,'MathematicalOperations']]],
  ['multiply',['multiply',['../classMathematicalOperations.html#aae54d9b1db279ce7b19a61022cf2687f',1,'MathematicalOperations']]]
];
