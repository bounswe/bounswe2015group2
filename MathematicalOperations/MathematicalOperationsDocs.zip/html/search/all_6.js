var searchData=
[
  ['power',['power',['../classMathematicalOperations.html#a2e67472fb054b3b495bdcbd20a3f90de',1,'MathematicalOperations']]]
];
